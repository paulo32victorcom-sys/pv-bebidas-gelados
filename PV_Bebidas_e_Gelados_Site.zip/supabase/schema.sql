-- PV Bebidas e Gelados: execute no SQL Editor do Supabase.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.admin_users where user_id = auth.uid()); $$;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price numeric(10,2) not null default 0 check(price >= 0),
  stock integer not null default 0 check(stock >= 0),
  image_url text,
  description text default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id bigint generated always as identity primary key,
  customer_name text not null,
  address text not null,
  fulfillment text not null check(fulfillment in ('Entrega','Retirada')),
  payment text not null check(payment in ('Pix','Dinheiro','Cartão')),
  items jsonb not null,
  total numeric(10,2) not null,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

drop policy if exists "public can view active products" on public.products;
create policy "public can view active products" on public.products for select using (active = true or public.is_admin());
drop policy if exists "admins manage products" on public.products;
create policy "admins manage products" on public.products for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins read orders" on public.orders;
create policy "admins read orders" on public.orders for select using (public.is_admin());
drop policy if exists "admins read admin users" on public.admin_users;
create policy "admins read admin users" on public.admin_users for select using (user_id = auth.uid());

-- Cria o pedido e baixa o estoque em uma única transação.
create or replace function public.place_order(
  p_customer_name text, p_address text, p_fulfillment text,
  p_payment text, p_items jsonb
) returns bigint
language plpgsql security definer
set search_path = public
as $$
declare
  item jsonb;
  product_row public.products%rowtype;
  order_total numeric(10,2) := 0;
  order_lines jsonb := '[]'::jsonb;
  new_id bigint;
  qty integer;
begin
  if length(trim(coalesce(p_customer_name,''))) < 2 then raise exception 'Informe seu nome.'; end if;
  if p_fulfillment not in ('Entrega','Retirada') then raise exception 'Tipo de recebimento inválido.'; end if;
  if p_payment not in ('Pix','Dinheiro','Cartão') then raise exception 'Pagamento inválido.'; end if;
  if p_fulfillment = 'Entrega' and length(trim(coalesce(p_address,''))) < 5 then raise exception 'Informe o endereço.'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then raise exception 'Carrinho vazio.'; end if;

  for item in select value from jsonb_array_elements(p_items) loop
    qty := (item->>'quantity')::integer;
    if qty < 1 or qty > 99 then raise exception 'Quantidade inválida.'; end if;
    select * into product_row from public.products
      where id = (item->>'product_id')::uuid and active = true for update;
    if not found then raise exception 'Um produto não está mais disponível.'; end if;
    if product_row.stock < qty then raise exception 'Estoque insuficiente para: %', product_row.name; end if;
    order_total := order_total + product_row.price * qty;
    order_lines := order_lines || jsonb_build_array(jsonb_build_object(
      'product_id', product_row.id, 'name', product_row.name,
      'quantity', qty, 'unit_price', product_row.price,
      'line_total', product_row.price * qty
    ));
    update public.products set stock = stock - qty where id = product_row.id;
  end loop;

  insert into public.orders(customer_name,address,fulfillment,payment,items,total)
  values(trim(p_customer_name),trim(p_address),p_fulfillment,p_payment,order_lines,order_total)
  returning id into new_id;
  return new_id;
end;
$$;
grant execute on function public.place_order(text,text,text,text,jsonb) to anon, authenticated;

-- Bucket público para fotos de produtos. Upload/alteração/exclusão somente para administradores.
insert into storage.buckets (id,name,public) values ('product-images','product-images',true)
on conflict (id) do update set public = true;
drop policy if exists "Public product images" on storage.objects;
create policy "Public product images" on storage.objects for select using (bucket_id = 'product-images');
drop policy if exists "Admins upload product images" on storage.objects;
create policy "Admins upload product images" on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.is_admin());
drop policy if exists "Admins update product images" on storage.objects;
create policy "Admins update product images" on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.is_admin()) with check (bucket_id = 'product-images' and public.is_admin());
drop policy if exists "Admins delete product images" on storage.objects;
create policy "Admins delete product images" on storage.objects for delete to authenticated using (bucket_id = 'product-images' and public.is_admin());

-- Produtos iniciais: os preços não informados ficam em R$ 0,00 até você editá-los.
insert into public.products(name,price,stock) values
('Coca-Cola lata 350 ml',0,0),('Monster 473 ml',0,0),('Red Bull 250 ml',0,0),
('Skol lata',0,0),('Skol vidro',0,0),('Heineken',0,0),('Brahma',0,0),
('Gutinho',1.50,0),('Sorvete de 1 litro',15.00,0)
on conflict do nothing;
